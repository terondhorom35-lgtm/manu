(() => {
  const C = window.APP_CONFIG;
  const $ = (id) => document.getElementById(id);
  const state = {
    student: null, questions: [], answers: {}, startedAt: null,
    timerId: null, tabSwitches: 0, submitted: false,
    pdfDoc: null, filename: "", payload: null
  };

  // ---------- setup ----------
  $("title").textContent = C.ASSESSMENT_TITLE;
  document.title = C.ASSESSMENT_TITLE;
  const rules = [
    `${window.QUESTIONS.length} multiple-choice questions, ${C.MARKS_PER_QUESTION} mark each.`,
    C.DURATION_MINUTES ? `Time limit: ${C.DURATION_MINUTES} minutes. The test auto-submits when time ends.` : "No time limit.",
    C.MAX_TAB_SWITCHES ? `Switching tabs/apps is tracked; after ${C.MAX_TAB_SWITCHES} switches the test auto-submits.` : "",
    "Your PDF report is emailed to the instructor automatically."
  ].filter(Boolean);
  $("rules").innerHTML = rules.map(r => `<li>${r}</li>`).join("");

  const shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // ---------- start ----------
  $("startForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    state.student = { name: f.get("studentName").trim(), roll: f.get("roll").trim() };
    state.attemptId = "MT1-" + Date.now().toString(36).toUpperCase() + "-" + Math.random().toString(36).slice(2, 6).toUpperCase();
    state.startedAt = new Date();

    let qs = window.QUESTIONS.map((q, i) => ({ ...q, id: i }));
    if (C.SHUFFLE_QUESTIONS) qs = shuffle(qs);
    state.questions = qs.map(q => {
      let opts = q.options.map((t, i) => ({ t, correct: i === q.answer }));
      if (C.SHUFFLE_OPTIONS) opts = shuffle(opts);
      return { ...q, opts };
    });

    renderQuestions();
    $("studentInfo").innerHTML = `<strong>${esc(state.student.name)}</strong> · Roll ${esc(state.student.roll)} · Attempt ${state.attemptId}`;
    $("startView").classList.add("hidden");
    $("testView").classList.remove("hidden");
    if (C.DURATION_MINUTES) startTimer(C.DURATION_MINUTES * 60);
    window.addEventListener("beforeunload", warnUnload);
    document.addEventListener("visibilitychange", onVisibility);
    window.scrollTo(0, 0);
  });

  function renderQuestions() {
    $("questions").innerHTML = state.questions.map((q, n) => `
      <fieldset class="card q">
        <legend>Q${n + 1}. ${esc(q.q)}</legend>
        ${q.opts.map((o, k) => `
          <label class="opt"><input type="radio" name="q${n}" value="${k}"> ${esc(o.t)}</label>`).join("")}
      </fieldset>`).join("");
    $("testForm").addEventListener("change", (e) => {
      const n = Number(e.target.name.slice(1));
      state.answers[n] = Number(e.target.value);
      $("progress").textContent = `${Object.keys(state.answers).length} / ${state.questions.length} answered`;
    });
    $("progress").textContent = `0 / ${state.questions.length} answered`;
  }

  // ---------- timer & integrity ----------
  function startTimer(secs) {
    const el = $("timer"); el.classList.remove("hidden");
    const end = Date.now() + secs * 1000;
    const tick = () => {
      const left = Math.max(0, Math.round((end - Date.now()) / 1000));
      el.textContent = `${String(Math.floor(left / 60)).padStart(2, "0")}:${String(left % 60).padStart(2, "0")}`;
      el.classList.toggle("warn", left <= 60);
      if (left === 0) finish("Auto-submitted (time up)");
    };
    tick(); state.timerId = setInterval(tick, 1000);
  }
  function onVisibility() {
    if (document.hidden && !state.submitted) {
      state.tabSwitches++;
      if (C.MAX_TAB_SWITCHES && state.tabSwitches >= C.MAX_TAB_SWITCHES) finish("Auto-submitted (tab switching)");
      else if (C.MAX_TAB_SWITCHES) setTimeout(() => alert(`Warning: you left the test page (${state.tabSwitches}/${C.MAX_TAB_SWITCHES}).`), 300);
    }
  }
  function warnUnload(e) { if (!state.submitted) { e.preventDefault(); e.returnValue = ""; } }

  $("testForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const unanswered = state.questions.length - Object.keys(state.answers).length;
    if (unanswered && !confirm(`${unanswered} question(s) unanswered. Submit anyway?`)) return;
    finish("Manual submission");
  });

  // ---------- finish ----------
  function finish(mode) {
    if (state.submitted) return;
    state.submitted = true;
    clearInterval(state.timerId);
    window.removeEventListener("beforeunload", warnUnload);
    document.querySelectorAll("#testForm input").forEach(i => i.disabled = true);

    let score = 0;
    const rows = state.questions.map((q, n) => {
      const chosen = state.answers[n];
      const ok = chosen !== undefined && q.opts[chosen].correct;
      if (ok) score += C.MARKS_PER_QUESTION;
      return {
        no: n + 1, q: q.q,
        given: chosen === undefined ? "Not answered" : q.opts[chosen].t,
        correct: q.opts.find(o => o.correct).t,
        result: ok ? "Correct" : (chosen === undefined ? "—" : "Wrong")
      };
    });
    const max = state.questions.length * C.MARKS_PER_QUESTION;
    const submittedAt = new Date();

    buildPdf(rows, score, max, mode, submittedAt);
    state.payload = {
      recipient: C.RECIPIENT,
      filename: state.filename,
      pdfBase64: state.pdfDoc.output("datauristring").split(",")[1],
      studentName: state.student.name,
      roll: state.student.roll,
      assessmentTitle: C.ASSESSMENT_TITLE,
      course: C.COURSE,
      score, max, mode,
      submittedAt: submittedAt.toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
      attemptId: state.attemptId
    };

    $("testView").classList.add("hidden");
    $("timer").classList.add("hidden");
    $("resultView").classList.remove("hidden");
    $("scoreLine").textContent = `Score: ${score} / ${max}  (${mode})`;
    window.scrollTo(0, 0);
    send();
  }

  function buildPdf(rows, score, max, mode, submittedAt) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const fmt = (d) => d.toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });
    doc.setFontSize(16); doc.text(C.ASSESSMENT_TITLE + " — Response Report", 40, 50);
    doc.setFontSize(10);
    const meta = [
      ["Student", state.student.name], ["Roll No.", state.student.roll],
      ["Score", `${score} / ${max}`], ["Submission mode", mode],
      ["Started", fmt(state.startedAt)], ["Submitted", fmt(submittedAt)],
      ["Tab switches", String(state.tabSwitches)], ["Attempt ID", state.attemptId]
    ];
    doc.autoTable({ startY: 65, body: meta, theme: "plain", styles: { fontSize: 10, cellPadding: 3 },
      columnStyles: { 0: { fontStyle: "bold", cellWidth: 110 } } });
    doc.autoTable({
      startY: doc.lastAutoTable.finalY + 15,
      head: [["#", "Question", "Answer given", "Correct answer", "Result"]],
      body: rows.map(r => [r.no, r.q, r.given, r.correct, r.result]),
      styles: { fontSize: 9, cellPadding: 4, valign: "top" },
      headStyles: { fillColor: [47, 111, 237] },
      columnStyles: { 0: { cellWidth: 22 }, 4: { cellWidth: 52 } },
      didParseCell: (d) => {
        if (d.section === "body" && d.column.index === 4)
          d.cell.styles.textColor = d.cell.raw === "Correct" ? [20, 130, 60] : [190, 40, 40];
      }
    });
    state.pdfDoc = doc;
    state.filename = `MT1_${state.student.roll}_${state.student.name}`.replace(/[^A-Za-z0-9._-]/g, "_") + ".pdf";
  }

  // ---------- send to Apps Script ----------
  async function send() {
    const status = $("sendStatus");
    status.className = "status"; status.textContent = "Sending report to instructor…";
    $("btnRetry").classList.add("hidden");
    const opts = { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(state.payload) };
    try {
      const res = await fetch(C.API_URL, opts);
      const out = await res.json();
      if (!out.ok) throw new Error(out.error || "Server rejected the report");
      status.className = "status ok"; status.textContent = "✔ Report emailed to the instructor.";
    } catch (err) {
      // Fallback: some browsers block reading the cross-origin reply; send blind.
      if (err instanceof TypeError) {
        try {
          await fetch(C.API_URL, { ...opts, mode: "no-cors" });
          status.className = "status ok";
          status.textContent = "✔ Report sent. Please also download your copy below.";
          return;
        } catch (_) { /* fall through */ }
      }
      status.className = "status err";
      status.textContent = "✖ Could not send: " + err.message + ". Download the PDF and give it to your instructor.";
      $("btnRetry").classList.remove("hidden");
    }
  }

  $("btnDownload").addEventListener("click", () => state.pdfDoc && state.pdfDoc.save(state.filename));
  $("btnRetry").addEventListener("click", send);
})();
