// ===== MT-I Online Class Test — configuration =====
window.APP_CONFIG = {
  // Google Apps Script Web App (emails the PDF report)
  DEPLOYMENT_ID: "AKfycbx58iYEbYZZ8l1AE1Pn1dCKex2BMNc0geZYpRV-EBGs5Mit4vAA9UalJ1l0Us7lzMIx",
  API_URL: "https://script.google.com/macros/s/AKfycbx58iYEbYZZ8l1AE1Pn1dCKex2BMNc0geZYpRV-EBGs5Mit4vAA9UalJ1l0Us7lzMIx/exec",

  // Must match DEFAULT_RECIPIENT in apps-script/Code.gs
  RECIPIENT: "jontorapadang35@gmail.com",

  ASSESSMENT_TITLE: "MT-I Online Class Test",
  COURSE: "MT-I",
  DURATION_MINUTES: 20,      // set 0 for no timer
  MARKS_PER_QUESTION: 1,
  SHUFFLE_QUESTIONS: true,
  SHUFFLE_OPTIONS: true,
  MAX_TAB_SWITCHES: 3        // auto-submit after this many tab switches; 0 = off
};
