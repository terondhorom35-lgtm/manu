/**
 * MT-I Online Class Test: email the generated PDF report to the instructor.
 * Deploy this Apps Script as a Web App: Execute as Me; access Anyone.
 * Deployment ID: AKfycbx58iYEbYZZ8l1AE1Pn1dCKex2BMNc0geZYpRV-EBGs5Mit4vAA9UalJ1l0Us7lzMIx
 */
const DEFAULT_RECIPIENT = 'jontorapadang35@gmail.com';

function doPost(e) {
  try {
    const raw = e && e.postData && e.postData.contents;
    if (!raw) throw new Error('Missing request body');
    const data = JSON.parse(raw);
    const recipient = String(data.recipient || DEFAULT_RECIPIENT).trim();
    if (recipient !== DEFAULT_RECIPIENT) throw new Error('Recipient is not authorized');
    if (!data.pdfBase64) throw new Error('Missing PDF attachment');
    const safeName = String(data.filename || 'MT1_Assessment_Report.pdf').replace(/[^A-Za-z0-9._-]/g, '_');
    const bytes = Utilities.base64Decode(data.pdfBase64);
    const pdf = Utilities.newBlob(bytes, 'application/pdf', safeName);
    const subject = 'MT-I Assessment Report: ' + (data.studentName || 'Student') + ' (' + (data.roll || 'No roll') + ')';
    const body = [
      'An assessment response report was automatically submitted.', '',
      'Student: ' + (data.studentName || ''),
      'Roll No.: ' + (data.roll || ''),
      'Assessment: ' + (data.assessmentTitle || data.course || 'MT-I Online Class Test'),
      'Score: ' + (data.score ?? '') + ' / ' + (data.max ?? ''),
      'Submission mode: ' + (data.mode || ''),
      'Submitted at: ' + (data.submittedAt || ''),
      'Attempt ID: ' + (data.attemptId || ''), '',
      'The PDF report is attached.'
    ].join('\n');
    MailApp.sendEmail({ to: recipient, subject: subject, body: body, attachments: [pdf], name: 'MT-I Online Assessment' });
    return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    console.error(err && err.stack ? err.stack : err);
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: String(err) })).setMimeType(ContentService.MimeType.JSON);
  }
}

function testEmailPermission() {
  MailApp.sendEmail(DEFAULT_RECIPIENT, 'MT-I report email test', 'Email permission is working.');
}
