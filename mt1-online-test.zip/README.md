# MT-I Online Class Test

A browser-based MCQ class test. When a student submits, the page builds a PDF response report (name, roll, score, every answer) and sends it to a Google Apps Script web app, which emails it to the instructor.

- **Frontend:** static site on GitHub Pages
- **Backend:** Google Apps Script → `MailApp` → instructor's Gmail
- **Web App URL:** https://script.google.com/macros/s/AKfycbx58iYEbYZZ8l1AE1Pn1dCKex2BMNc0geZYpRV-EBGs5Mit4vAA9UalJ1l0Us7lzMIx/exec

## Features
- Student name + roll entry, attempt ID per attempt
- Shuffled questions and options
- Countdown timer with auto-submit
- Tab-switch tracking with auto-submit after a limit
- PDF report (jsPDF) emailed automatically; student can download a copy
- Retry button if sending fails

## Structure
```
.
├── index.html              # Test page
├── config.js               # URL, recipient, timer, shuffle, tab-switch limit
├── questions.js            # Question bank (edit this)
├── assets/
│   ├── test.js             # Test logic, scoring, PDF, submission
│   └── style.css
├── apps-script/
│   ├── Code.gs             # Backend (copy into script.google.com)
│   └── appsscript.json
└── .github/workflows/pages.yml
```

## Edit the test
- **Questions:** `questions.js` — `answer` is the index of the correct option (0 = first).
- **Settings:** `config.js` — `DURATION_MINUTES`, `MARKS_PER_QUESTION`, `MAX_TAB_SWITCHES`, shuffling.
- `RECIPIENT` in `config.js` must equal `DEFAULT_RECIPIENT` in `Code.gs`, otherwise the script rejects the report.

## Publish on GitHub
```bash
git init
git add .
git commit -m "MT-I online class test"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
Then **Settings → Pages → Source: GitHub Actions**. Share `https://<your-username>.github.io/<repo-name>/` with students.

## Apps Script setup
1. Paste `apps-script/Code.gs` into the script project.
2. Run `testEmailPermission` once and approve Gmail access.
3. **Deploy → Manage deployments → Edit → New version** (keeps the same URL). Execute as: *Me*; Who has access: *Anyone*.
4. If you create a new deployment instead, update `API_URL` in `config.js`.

## Notes
- Gmail free accounts can send about 100 emails/day via Apps Script — enough for a class, not for repeated large tests in one day.
- Requests are sent as `text/plain` to avoid a CORS preflight, which Apps Script cannot answer.
- Answers are scored in the browser, so this suits class tests rather than high-stakes exams; a determined student could read `questions.js`.
