// ===== Question bank — edit freely =====
// answer = index of the correct option (0 = first option)
window.QUESTIONS = [
  { q: "Which of the following is NOT a casting process?",
    options: ["Sand casting", "Die casting", "Investment casting", "Forging"], answer: 3 },
  { q: "Allowance provided on a pattern to compensate for shrinkage of metal is called:",
    options: ["Draft allowance", "Shrinkage allowance", "Machining allowance", "Distortion allowance"], answer: 1 },
  { q: "The taper provided on vertical faces of a pattern for easy withdrawal is:",
    options: ["Draft", "Shake", "Camber", "Fillet"], answer: 0 },
  { q: "Core prints are provided on a pattern to:",
    options: ["Improve surface finish", "Support the core in the mould", "Reduce shrinkage", "Act as a riser"], answer: 1 },
  { q: "In arc welding, the electrode coating (flux) mainly serves to:",
    options: ["Increase current", "Shield the weld pool from atmosphere", "Cool the joint", "Increase voltage"], answer: 1 },
  { q: "Oxy-acetylene flame used for welding most steels is:",
    options: ["Oxidising flame", "Carburising flame", "Neutral flame", "Reducing flame"], answer: 2 },
  { q: "Hot working of metals is carried out:",
    options: ["Below recrystallisation temperature", "Above recrystallisation temperature", "At room temperature only", "At melting point"], answer: 1 },
  { q: "Which process produces seamless tubes?",
    options: ["Piercing", "Spinning", "Coining", "Embossing"], answer: 0 },
  { q: "A riser in a casting mould is used to:",
    options: ["Pour metal", "Feed molten metal to compensate shrinkage", "Hold the core", "Vent gases only"], answer: 1 },
  { q: "Soldering differs from brazing mainly in the:",
    options: ["Type of joint", "Filler metal melting temperature", "Use of flux", "Base metal melting"], answer: 1 }
];
